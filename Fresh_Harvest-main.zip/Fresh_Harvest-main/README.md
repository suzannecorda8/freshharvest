# Fresh_Harvest
Fresh Harvest is an E-commerce platform that connects local vegetable vendors with customers, offering a wide selection of fresh fruits and vegetables for online purchase, fostering support for local businesses over large supermarkets.
